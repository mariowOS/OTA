(function() {
  'use strict';

  // === Color utilities ===
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
        case g: h = ((b - r) / d + 2) / 6; break;
        case b: h = ((r - g) / d + 4) / 6; break;
      }
    }
    return [h, s, l];
  }

  function hslToRgb(h, s, l) {
    let r, g, b;
    if (s === 0) { r = g = b = l; }
    else {
      const hue2rgb = (p, q, t) => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      };
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1/3);
    }
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  }

  function hexToRgb(hex) {
    const v = parseInt(hex.replace('#', ''), 16);
    return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
  }

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(c => Math.round(c).toString(16).padStart(2, '0')).join('');
  }

  // === Tonal palette generation (Material You style) ===
  function generateTonalPalette(hue, chroma) {
    // Tone values: 0-100, where higher = lighter
    // Material You uses specific tones: 0,10,20,30,40,50,60,70,80,90,95,99,100
    const tones = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 99, 100];
    const palette = {};
    tones.forEach(tone => {
      // tone 0 = black, tone 100 = white
      if (tone === 0) { palette[tone] = '#000000'; return; }
      if (tone === 100) { palette[tone] = '#ffffff'; return; }
      // Map tone to lightness (inverted: higher tone = lighter)
      const lightness = tone / 100;
      // Chroma is reduced at very low and very high lightness
      const effectiveChroma = chroma * (1 - Math.abs(lightness - 0.5) * 0.6);
      // Convert HSL to RGB
      const [r, g, b] = hslToRgb(hue, effectiveChroma, lightness);
      palette[tone] = rgbToHex(r, g, b);
    });
    return palette;
  }

  // === Extract dominant color from image ===
  function extractColors(imageUrl, callback) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      // Sample at smaller size for performance
      const sampleSize = 64;
      canvas.width = sampleSize;
      canvas.height = sampleSize;
      ctx.drawImage(img, 0, 0, sampleSize, sampleSize);

      const imageData = ctx.getImageData(0, 0, sampleSize, sampleSize);
      const data = imageData.data;
      const pixels = [];

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i], g = data[i+1], b = data[i+2];
        const a = data[i+3];
        if (a < 128) continue;
        // Skip very dark and very light pixels
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        if (brightness < 10 || brightness > 245) continue;
        pixels.push([r, g, b]);
      }

      if (pixels.length === 0) {
        callback('#3584e4'); // fallback blue
        return;
      }

      // Simple color quantization using box averaging
      const boxSize = 32;
      const buckets = {};
      pixels.forEach(([r, g, b]) => {
        const key = `${Math.floor(r/boxSize)},${Math.floor(g/boxSize)},${Math.floor(b/boxSize)}`;
        if (!buckets[key]) buckets[key] = { r: 0, g: 0, b: 0, count: 0 };
        buckets[key].r += r;
        buckets[key].g += g;
        buckets[key].b += b;
        buckets[key].count++;
      });

      // Find the most populous bucket
      let dominantKey = null, maxCount = 0;
      Object.keys(buckets).forEach(key => {
        if (buckets[key].count > maxCount) {
          maxCount = buckets[key].count;
          dominantKey = key;
        }
      });

      if (!dominantKey) {
        callback('#3584e4');
        return;
      }

      const bucket = buckets[dominantKey];
      const avgR = bucket.r / bucket.count;
      const avgG = bucket.g / bucket.count;
      const avgB = bucket.b / bucket.count;
      callback(rgbToHex(avgR, avgG, avgB));
    };
    img.onerror = function() {
      callback('#3584e4'); // fallback blue on error
    };
    img.src = imageUrl;
  }

  // === Apply Material You theme ===
  function applyMonetTheme(seedColor) {
    const [sr, sg, sb] = hexToRgb(seedColor);
    const [h, s, l] = rgbToHsl(sr, sg, sb);

    // Primary: use the seed color's hue with adjusted chroma
    const primaryPalette = generateTonalPalette(h, Math.min(s + 0.15, 0.8));

    // Secondary: shift hue by ~30 degrees, lower chroma
    const secondaryHue = (h + 30/360) % 1;
    const secondaryPalette = generateTonalPalette(secondaryHue, Math.max(s - 0.1, 0.15));

    // Tertiary: shift hue by ~60 degrees in opposite direction
    const tertiaryHue = (h - 60/360 + 1) % 1;
    const tertiaryPalette = generateTonalPalette(tertiaryHue, Math.max(s - 0.05, 0.2));

    // Neutral: same hue, very low chroma
    const neutralPalette = generateTonalPalette(h, 0.04);

    // Neutral variant: slightly different hue, very low chroma
    const neutralVariantHue = (h + 10/360) % 1;
    const neutralVariantPalette = generateTonalPalette(neutralVariantHue, 0.06);

    // Error: fixed red hue
    const errorPalette = generateTonalPalette(4/360, 0.7);

    const vars = {
      '--md-sys-color-primary': primaryPalette[40],
      '--md-sys-color-on-primary': primaryPalette[100],
      '--md-sys-color-primary-container': primaryPalette[90],
      '--md-sys-color-on-primary-container': primaryPalette[10],
      '--md-sys-color-primary-fixed': primaryPalette[90],
      '--md-sys-color-primary-fixed-dim': primaryPalette[80],
      '--md-sys-color-on-primary-fixed': primaryPalette[10],
      '--md-sys-color-on-primary-fixed-variant': primaryPalette[30],

      '--md-sys-color-secondary': secondaryPalette[40],
      '--md-sys-color-on-secondary': secondaryPalette[100],
      '--md-sys-color-secondary-container': secondaryPalette[90],
      '--md-sys-color-on-secondary-container': secondaryPalette[10],

      '--md-sys-color-tertiary': tertiaryPalette[40],
      '--md-sys-color-on-tertiary': tertiaryPalette[100],
      '--md-sys-color-tertiary-container': tertiaryPalette[90],
      '--md-sys-color-on-tertiary-container': tertiaryPalette[10],

      '--md-sys-color-error': errorPalette[40],
      '--md-sys-color-on-error': errorPalette[100],
      '--md-sys-color-error-container': errorPalette[90],
      '--md-sys-color-on-error-container': errorPalette[10],

      '--md-sys-color-outline': neutralVariantPalette[50],
      '--md-sys-color-outline-variant': neutralVariantPalette[80],
      '--md-sys-color-surface': '#1c1b1f',
      '--md-sys-color-on-surface': neutralPalette[90],
      '--md-sys-color-surface-dim': '#141318',
      '--md-sys-color-surface-bright': '#3b383e',
      '--md-sys-color-surface-container-lowest': '#0e0d11',
      '--md-sys-color-surface-container-low': '#1c1b1f',
      '--md-sys-color-surface-container': '#201f24',
      '--md-sys-color-surface-container-high': '#2b2930',
      '--md-sys-color-surface-container-highest': '#36343b',
      '--md-sys-color-on-surface-variant': neutralVariantPalette[80],
      '--md-sys-color-inverse-surface': neutralPalette[90],
      '--md-sys-color-inverse-on-surface': neutralPalette[20],
      '--md-sys-color-inverse-primary': primaryPalette[80],

      '--md-sys-color-background': '#1c1b1f',
      '--md-sys-color-on-background': neutralPalette[90],

      '--md-sys-color-surface-tint': primaryPalette[40],
      '--md-sys-color-scrim': '#000000',

      '--md-sys-color-primary-palette': JSON.stringify(primaryPalette),
      '--md-ref-palette-primary40': primaryPalette[40],
      '--md-ref-palette-primary80': primaryPalette[80],
      '--md-ref-palette-primary90': primaryPalette[90],
      '--md-ref-palette-secondary40': secondaryPalette[40],
      '--md-ref-palette-tertiary40': tertiaryPalette[40],
      '--md-ref-palette-neutral90': neutralPalette[90],
      '--md-ref-palette-neutral10': neutralPalette[10],
      '--md-ref-palette-neutral-variant50': neutralVariantPalette[50],
      '--md-ref-palette-neutral-variant80': neutralVariantPalette[80],
    };

    const root = document.documentElement;
    Object.keys(vars).forEach(key => {
      root.style.setProperty(key, vars[key]);
    });

    // Also set legacy accent color for backward compatibility
    root.style.setProperty('--accent-color', primaryPalette[40]);
    root.style.setProperty('--accent-color-rgb', [sr, sg, sb].join(','));

    // Dispatch event for iframes
    window.dispatchEvent(new CustomEvent('monet-theme-applied', { detail: vars }));

    // Store in sessionStorage for iframes to pick up
    try {
      sessionStorage.setItem('monet-theme', JSON.stringify(vars));
    } catch(e) {}

    return vars;
  }

  // === Initialize ===
  function initMonet() {
    // Check if theme already applied
    const stored = sessionStorage.getItem('monet-theme');
    if (stored && window === window.top) {
      try {
        const vars = JSON.parse(stored);
        const root = document.documentElement;
        Object.keys(vars).forEach(key => {
          root.style.setProperty(key, vars[key]);
        });
        return;
      } catch(e) {}
    }

    // Try multiple wallpaper paths
    const urls = [
      '/desktop/assets/wallpaper.user.png',
      '/desktop/assets/wallpaper.png',
      '/desktop/assets/wallpaper.factory.png'
    ];

    function tryUrl(index) {
      if (index >= urls.length) {
        applyMonetTheme('#3584e4');
        return;
      }
      fetch(urls[index], { method: 'HEAD' })
        .then(res => {
          if (res.ok) {
            extractColors(urls[index] + '?t=' + Date.now(), function(color) {
              applyMonetTheme(color);
            });
          } else {
            tryUrl(index + 1);
          }
        })
        .catch(() => tryUrl(index + 1));
    }

    tryUrl(0);
  }

  // === Listen for parent theme (if in iframe) ===
  if (window !== window.top) {
    window.addEventListener('monet-theme-applied', function(e) {
      const root = document.documentElement;
      Object.keys(e.detail).forEach(key => {
        root.style.setProperty(key, e.detail[key]);
      });
    });

    // Also listen for postMessage from parent
    window.addEventListener('message', function(e) {
      if (e.data && e.data.type === 'monet-theme') {
        const root = document.documentElement;
        Object.keys(e.data.vars).forEach(key => {
          root.style.setProperty(key, e.data.vars[key]);
        });
      }
    });

    // Request theme from parent
    window.parent.postMessage({ type: 'monet-theme-request' }, '*');
  }

  // Broadcast theme to child iframes
  function broadcastToIframes(vars) {
    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(iframe => {
      try {
        iframe.contentWindow.postMessage({ type: 'monet-theme', vars: vars }, '*');
      } catch(e) {}
    });
  }

  // Override applyMonetTheme to broadcast
  const originalApply = applyMonetTheme;
  applyMonetTheme = function(seedColor) {
    const vars = originalApply(seedColor);
    if (window === window.top) {
      broadcastToIframes(vars);
    }
    return vars;
  };

  // Export to window
  window.MonetEngine = {
    extractColors: extractColors,
    applyMonetTheme: applyMonetTheme,
    init: initMonet,
    generateTonalPalette: generateTonalPalette
  };

  // Run on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMonet);
  } else {
    initMonet();
  }
})();
